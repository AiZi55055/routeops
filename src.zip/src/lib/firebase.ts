// src/lib/firebase.ts
// Firebase singletons (app, auth, db, rtdb, storage, functions) + helpers.
// - Keeps session with browserLocalPersistence
// - Exposes functions in region "asia-southeast1"
// - Robust Google Sign-In (popup with fallback to redirect)
// - Optional emulator wiring via VITE_USE_EMULATORS=true

import { initializeApp } from "firebase/app";
import {
  getAuth,
  browserLocalPersistence,
  setPersistence,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  browserPopupRedirectResolver,
  signOut,
  connectAuthEmulator, // <-- add this
} from "firebase/auth";
import { getFirestore, connectFirestoreEmulator } from "firebase/firestore";
import { getDatabase, connectDatabaseEmulator } from "firebase/database";
import {
  getFunctions,
  httpsCallable,
  connectFunctionsEmulator,
} from "firebase/functions";
import { getStorage, connectStorageEmulator } from "firebase/storage";

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FB_API_KEY,
  authDomain: import.meta.env.VITE_FB_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FB_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FB_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FB_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FB_APP_ID,
  databaseURL: import.meta.env.VITE_DATABASE_URL,
};

export const app = initializeApp(firebaseConfig);

// Auth
export const auth = getAuth(app);
// keep user signed in across reloads
setPersistence(auth, browserLocalPersistence).catch((e) => {
  console.warn("Auth persistence failed:", e);
});

// Firestore & RTDB & Storage
export const db = getFirestore(app);
export const rtdb = getDatabase(app);
export const storage = getStorage(app);

// Cloud Functions (region must match your deploy)
export const functions = getFunctions(app, "asia-southeast1");

// ---- Emulator wiring (optional) ----
// Enable by setting VITE_USE_EMULATORS=true in your .env.local
const USE_EMUS =
  import.meta.env.VITE_USE_EMULATORS === "true" ||
  (import.meta.env.DEV && import.meta.env.VITE_USE_EMULATORS !== "false");

if (USE_EMUS) {
  try {
    // defaults from firebase emulators:start
    connectAuthEmulator(auth, "http://localhost:9099", { disableWarnings: true });
  } catch {}
  try {
    connectFirestoreEmulator(db, "localhost", 8080);
  } catch {}
  try {
    connectDatabaseEmulator(rtdb, "localhost", 9000);
  } catch {}
  try {
    connectFunctionsEmulator(functions, "localhost", 5001);
  } catch {}
  try {
    connectStorageEmulator(storage, "localhost", 9199);
  } catch {}
  console.log("[FB] emulators connected");
}

// ---- Sign-in helpers (robust popup with redirect fallback) ----
const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: "select_account" });

export async function signInWithGoogle() {
  // Try popup first (with explicit resolver for some isolated contexts),
  // then fallback to redirect if blocked (COOP, 3rd-party cookies, etc).
  try {
    const cred = await signInWithPopup(auth, googleProvider, browserPopupRedirectResolver);
    return cred.user;
  } catch (err) {
    // Popup failed — use redirect
    await signInWithRedirect(auth, googleProvider);
    // After redirect completes, your app will reload. Handle result in handleRedirectResult().
    return null;
  }
}

// Call once on app start (e.g., in your root component's effect)
export async function handleRedirectResult() {
  try {
    const res = await getRedirectResult(auth);
    if (res?.user) {
      console.log("[Auth] redirect sign-in success:", res.user.uid);
    }
  } catch (e) {
    console.warn("[Auth] redirect sign-in failed:", e);
  }
}

export async function signOutUser() {
  await signOut(auth);
}

// ---- Callable wrappers ----
// Phase 3 optimizer
export const callOptimize = (data: any) =>
  httpsCallable(functions, "optimizeRoutesV2")(data);

// (Add more wrappers as needed, e.g. enrich / seed callables)

// ---- Diagnostics ----
console.log(
  "[FB-INIT]",
  window.location.origin,
  "key suffix:",
  (firebaseConfig.apiKey || "").slice(-8)
);
console.log("FB key suffix", (import.meta.env.VITE_FB_API_KEY || "").slice(-8));
console.log("Maps key suffix", (import.meta.env.VITE_GOOGLE_MAPS_API_KEY || "").slice(-8));
