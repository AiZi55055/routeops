/// <reference types="vite/client" />
declare module 'virtual:pwa-register';
