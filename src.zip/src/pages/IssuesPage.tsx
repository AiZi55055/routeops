export default function IssuesPage(){ return <div className="p-4">⚠️ Report an issue</div> }
