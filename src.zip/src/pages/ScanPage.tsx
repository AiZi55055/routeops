export default function ScanPage(){ return <div className="p-4">📷 Scan (OCR) coming soon</div> }
