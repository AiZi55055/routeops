export default function RoutePage(){ return <div className="p-4">📍 Your route will appear here</div> }
