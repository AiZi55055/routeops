"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = ScanPage;
function ScanPage() { return <div className="p-4">📷 Scan (OCR) coming soon</div>; }
//# sourceMappingURL=ScanPage.js.map