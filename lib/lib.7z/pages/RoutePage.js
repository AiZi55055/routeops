"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = RoutePage;
function RoutePage() { return <div className="p-4">📍 Your route will appear here</div>; }
//# sourceMappingURL=RoutePage.js.map