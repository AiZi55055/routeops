"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = IssuesPage;
function IssuesPage() { return <div className="p-4">⚠️ Report an issue</div>; }
//# sourceMappingURL=IssuesPage.js.map