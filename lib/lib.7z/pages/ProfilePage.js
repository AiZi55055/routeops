"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = ProfilePage;
function ProfilePage() { return <div className="p-4">🙍 Profile</div>; }
//# sourceMappingURL=ProfilePage.js.map