// functions/src/index.ts
import { setGlobalOptions } from "firebase-functions/v2";
import * as admin from "firebase-admin";
setGlobalOptions({ region: "asia-southeast1" });
if (admin.apps.length === 0) admin.initializeApp();
export { optimizeRoutesV2 } from './optimizeRoutesV2';
export { enrichRoutePolylines } from './enrichRoute';

export { seedMockJobs } from "./seedMock";
export { optimizeRoutes } from "./optimizeRoutes";
//export { ocrOnUpload } from "./ocrOnUpload"; // <- add this
export { devSetRole } from "./devSetRole";
export { enrichAllRoutes } from "./enrichAllRoutes"; 

export { setClaimOnce } from "./util/setClaimOnce";
