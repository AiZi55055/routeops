// functions/src/enrichAllRoutes.ts
/**
 * Enrich many routes with configured concurrency:
 * - routeConcurrency: number of routes processed in parallel (default 3)
 * - legConcurrency: number of legs per route processed in parallel (default 5)
 * - Optional filters: routeIds whitelist, companyId, limit, updatedBefore
 *
 * Calls the single-route callable (enrichRoutePolylines) internally via code,
 * not via HTTP, by importing and invoking its logic? -> Simpler: we just
 * re-call the callable locally using the Admin SDK wrapper (httpsCallable isn't available server-side),
 * so we *perform enrichment inline here* with the same helper used in enrichRoute.ts.
 *
 * For simplicity and fewer moving parts, this module loads stops and enriches here,
 * reusing the same helpers as enrichRoute.ts (duplicated small subset).
 */

import * as admin from "firebase-admin";
if (admin.apps.length === 0) admin.initializeApp();

import { onCall, HttpsError } from "firebase-functions/v2/https";
import * as logger from "firebase-functions/logger";
import { getFirestore, FieldValue } from "firebase-admin/firestore";
import { requireRole } from "./authz";
import * as travel from "./travelCache";

type LatLng = { lat: number; lng: number };

type EnrichAllRequest = {
  // route selection
  routeIds?: string[];
  companyId?: string;
  limit?: number; // max routes to process
  updatedBefore?: number; // epoch ms

  // tuning
  routeConcurrency?: number; // default 3
  legConcurrency?: number;   // default 5
  shortHopMeters?: number;   // default 20
  force?: boolean;
};

type EnrichAllResponse = {
  routesProcessed: number;
  routesTotal: number;
  cacheHits: number;
  cacheMisses: number;
};

const db = getFirestore();
const ENV = {
  REGION: "asia-southeast1",
  ROUTE_CONCURRENCY: int(process.env.ENRICH_ROUTE_CONCURRENCY, 3), // Phase 3: 2–3
  LEG_CONCURRENCY: int(process.env.ENRICH_LEG_CONCURRENCY, 5),     // Phase 3: 4–6
  SHORT_HOP_METERS: int(process.env.SHORT_HOP_METERS, 20),
};

function int(v: any, d: number) {
  const n = Number(v);
  return Number.isFinite(n) ? n : d;
}

export const enrichAllRoutes = onCall(
  { region: ENV.REGION, cors: true, maxInstances: 30 },
  async (req): Promise<EnrichAllResponse> => {
    await requireRole(req, ["admin", "supervisor"]);

    const data = (req.data ?? {}) as EnrichAllRequest;
    const routeIds = Array.isArray(data.routeIds)
      ? data.routeIds.filter((s) => typeof s === "string" && s.trim())
      : null;

    const routeConcurrency = clamp(
      data.routeConcurrency ?? ENV.ROUTE_CONCURRENCY,
      1,
      10
    );
    const legConcurrency = clamp(
      data.legConcurrency ?? ENV.LEG_CONCURRENCY,
      1,
      10
    );
    const shortHopMeters = clamp(
      data.shortHopMeters ?? ENV.SHORT_HOP_METERS,
      0,
      200
    );
    const limit = clamp(data.limit ?? 50, 1, 500);

    logger.info("[ENRICH:all] start", {
      routeIds: routeIds?.length ?? null,
      companyId: data.companyId ?? null,
      limit,
      routeConcurrency,
      legConcurrency,
      shortHopMeters,
    });

    // Pick route IDs to process
    let ids: string[] = [];
    if (routeIds && routeIds.length) {
      ids = routeIds.slice(0, limit);
    } else {
      // Basic selection: latest updated routes (optionally by companyId if present on doc)
      let q = db.collection("routes").orderBy("updatedAt", "desc").limit(limit);
      if (data.companyId) {
        q = db.collection("routes")
          .where("companyId", "==", data.companyId)
          .orderBy("updatedAt", "desc")
          .limit(limit);
      }
      if (data.updatedBefore) {
        q = q.where("updatedAt", "<", admin.firestore.Timestamp.fromMillis(data.updatedBefore));
      }
      const qs = await q.get();
      ids = qs.docs.map((d) => d.id);
    }

    const routesTotal = ids.length;
    if (!routesTotal) {
      return { routesProcessed: 0, routesTotal: 0, cacheHits: 0, cacheMisses: 0 };
    }

    let processed = 0;
    let cacheHits = 0;
    let cacheMisses = 0;

    await mapLimit(ids, routeConcurrency, async (rid) => {
      const res = await enrichOne(rid, { legConcurrency, shortHopMeters });
      processed += 1;
      cacheHits += res.cacheHits;
      cacheMisses += res.cacheMisses;

      logger.info("[ENRICH:all] route done", {
        routeId: rid,
        legs: res.legs,
        cacheHitsAcc: cacheHits,
        cacheMissesAcc: cacheMisses,
        processed,
        routesTotal,
      });
    });

    logger.info("[ENRICH:all] done", {
      processed,
      routesTotal,
      cacheHits,
      cacheMisses,
    });

    return { routesProcessed: processed, routesTotal, cacheHits, cacheMisses };
  }
);

/* ---------------- helpers (same resilience as single-route) ---------------- */

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

function isLatLng(x: any): x is LatLng {
  return (
    x &&
    typeof x.lat === "number" &&
    Number.isFinite(x.lat) &&
    typeof x.lng === "number" &&
    Number.isFinite(x.lng)
  );
}

async function enrichOne(
  routeId: string,
  opts: { legConcurrency: number; shortHopMeters: number }
): Promise<{ legs: number; cacheHits: number; cacheMisses: number }> {
  const { legConcurrency, shortHopMeters } = opts;

  const stopsSnap = await db
    .collection(`routes/${routeId}/stops`)
    .orderBy("seq")
    .get();

  const stops = stopsSnap.docs
    .map((d) => ({ jobId: d.id, ...(d.data() as any) }))
    .filter((s) => typeof s.seq === "number")
    .sort((a, b) => a.seq - b.seq);

  if (stops.length < 1) {
    await db.doc(`routes/${routeId}`).set(
      { distanceMeters: 0, etaSeconds: 0, updatedAt: FieldValue.serverTimestamp() },
      { merge: true }
    );
    return { legs: 0, cacheHits: 0, cacheMisses: 0 };
  }

  const legs: Array<{ from: LatLng; to: LatLng; stopId: string; idx: number }> = [];
  let prev: LatLng | null = null;
  for (const s of stops) {
    const loc = s.location as LatLng | undefined;
    if (!loc || !isLatLng(loc)) continue;
    if (prev) legs.push({ from: prev, to: loc, stopId: s.jobId, idx: s.seq });
    prev = loc;
  }

  if (!legs.length) {
    await db.doc(`routes/${routeId}`).set(
      { distanceMeters: 0, etaSeconds: 0, updatedAt: FieldValue.serverTimestamp() },
      { merge: true }
    );
    return { legs: 0, cacheHits: 0, cacheMisses: 0 };
  }

  let hits = 0;
  let misses = 0;
  let meters = 0;
  let seconds = 0;

  await mapLimit(legs, legConcurrency, async (L) => {
    const seg = await getRouteSegment(L.from, L.to, shortHopMeters);
    hits += seg.cacheHit ? 1 : 0;
    misses += seg.cacheHit ? 0 : 1;
    meters += seg.distanceMeters;
    seconds += seg.seconds;
    try {
      await db.doc(`routes/${routeId}/stops/${L.stopId}`).set(
        {
          travel: {
            from: L.from,
            to: L.to,
            distanceMeters: seg.distanceMeters,
            durationSec: seg.seconds,
            polyline: seg.polyline ?? null,
          },
          updatedAt: FieldValue.serverTimestamp(),
        },
        { merge: true }
      );
    } catch (e) {
      logger.warn("[ENRICH:all] stop write failed", {
        routeId,
        jobId: L.stopId,
        err: String(e),
      });
    }
  });

  await db.doc(`routes/${routeId}`).set(
    {
      distanceMeters: Math.round(meters),
      etaSeconds: Math.round(seconds),
      updatedAt: FieldValue.serverTimestamp(),
    },
    { merge: true }
  );

  return { legs: legs.length, cacheHits: hits, cacheMisses: misses };
}

// Same resilient segment getter as enrichRoute.ts
async function getRouteSegment(
  from: LatLng,
  to: LatLng,
  shortHopMeters: number
): Promise<{ seconds: number; distanceMeters: number; polyline?: string | null; cacheHit: boolean }> {
  const metersCrow = haversineMeters(from, to);
  if (metersCrow <= shortHopMeters) {
    return { seconds: 0, distanceMeters: 0, polyline: null, cacheHit: true };
  }

  try {
    const fn = (travel as any)?.getRouteSegment;
    if (typeof fn === "function") {
      const seg = await fn(from, to, { shortHopMeters });
      if (seg && typeof seg.seconds === "number" && typeof seg.distanceMeters === "number") {
        return {
          seconds: seg.seconds,
          distanceMeters: seg.distanceMeters,
          polyline: seg.polyline ?? null,
          cacheHit: !!seg.cacheHit,
        };
      }
    }
  } catch {}

  try {
    const fn2 = (travel as any)?.getTravelSeconds;
    if (typeof fn2 === "function") {
      const res = await fn2(from, to, { shortHopMeters });
      const sec =
        res && typeof res === "object" && typeof res.seconds === "number"
          ? res.seconds
          : typeof res === "number"
          ? res
          : Math.max(1, Math.round((metersCrow / 30000) * 3600));
      return {
        seconds: sec,
        distanceMeters: metersCrow,
        polyline: null,
        cacheHit: !!(res && typeof res === "object" && res.cacheHit),
      };
    }
  } catch {}

  const speedMps = 30000 / 3600;
  return {
    seconds: Math.max(1, Math.round(metersCrow / speedMps)),
    distanceMeters: metersCrow,
    polyline: null,
    cacheHit: false,
  };
}

function haversineMeters(a: LatLng, b: LatLng) {
  const R = 6371000;
  const toRad = (x: number) => (x * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const la1 = toRad(a.lat);
  const la2 = toRad(b.lat);
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(la1) * Math.cos(la2) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(s)));
}

// Tiny concurrency limiter (no extra deps)
async function mapLimit<T, R>(
  items: T[],
  limit: number,
  worker: (item: T, index: number) => Promise<R>
): Promise<R[]> {
  const out: R[] = new Array(items.length);
  let i = 0;
  let inflight: Promise<void>[] = [];
  const next = async () => {
    const idx = i++;
    if (idx >= items.length) return;
    out[idx] = await worker(items[idx], idx);
    await next();
  };
  for (let k = 0; k < Math.min(limit, items.length); k++) {
    inflight.push(
      next().catch((e) => {
        logger.warn("[ENRICH:all] worker failed", { err: String(e) });
      })
    );
  }
  await Promise.all(inflight);
  return out.filter((x) => x !== undefined);
}
